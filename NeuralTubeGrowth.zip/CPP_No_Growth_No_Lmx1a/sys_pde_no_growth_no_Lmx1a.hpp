/**
 * Inspired from https://github.com/ifilot/turing/blob/master/src/two_dim_rd.cpp
*/
#pragma once

#include "std_include.h"
#include <eigen3/Eigen/Dense>
typedef Eigen::Array<double, Eigen::Dynamic, Eigen::Dynamic> ArrayXXd;
typedef Eigen::Array<unsigned int, Eigen::Dynamic, Eigen::Dynamic> ArrayXXu;
typedef Eigen::Array<int, Eigen::Dynamic, Eigen::Dynamic> ArrayXXi;

// Function to do integer power coz `pow()` is very slow
double int_pow(double val, int pow);

class NoGrowth2D {
public:

    /*
     * Setup rxn-diffusion system for diffusing species BMP (b), BMPi (i) and 
     * intra-cellular species pSMad (s)
     */

    //** Parameters **//
    // System params
    double H                = 2;                    // Hill coefficient
    double b0               = 0.7;                  // Initial concentration of BMP

    /* Reactions (GRN Params) */
    // BMP params
    double D_b              = 1;                    // Diffusion coefficient of BMP
    double a_b_s            = 1;                    // BMP activation rate by pSmad
    double K_b_s            = 0.1;                  // Hill threshold BMP activation
    double K_b_s_H          = int_pow(K_b_s, H);    // Hill threshold BMP activation powered 
                                                    // to hill-coefficient
    double d_b              = 1/5;                  // Degradation rate of BMP

    // BMP i params
    double D_i              = 1.5;                  // Diffusion coefficient of BMPi
    double a_i_s            = 1;                    // BMPi activation rate by pSmad
    double K_i_s            = 0.1;                  // Hill threshold BMPi activation
    double K_i_s_H          = int_pow(K_i_s, H);    // Hill threshold BMPi activation powered 
                                                    // to hill-coefficient
    double d_i              = 1/10;                 // Degradation rate of BMPi

    // pSmad params
    double a_s_b            = 1;                    // pSmad activation by BMP
    double K_s_b            = 0.1;                  // Hill threshold pSmad activation by BMP
    double K_s_b_H          = int_pow(K_s_b, H);    // Hill threshold pSmad activation by BMP powered
                                                    // to hill-coefficient
    double K_s_i            = 0.1;                  // Hill threshold pSmad activation by BMPi
    double K_s_i_H          = int_pow(K_s_i, H);    // Hill threshold pSmad activation by BMPi powered
                                                    // to hill-coefficient
    double d_s              = 1;                    // Degradation rate of pSmad

    /* System Parameters */
    unsigned int width;               // width of the system
    unsigned int height;              // height of the system
    unsigned int radius;              // radius of the cell colony
    double dx;                        // size of the space interval
    double dt;                        // size of the time interval
    unsigned int steps;               // total time, T
    unsigned int tsteps;              // number of time steps when to write a frame
    ArrayXXu in_colony;              // matrix to show if the pixel belongs to the colony

    /* Concentrations of chemical species */
    ArrayXXd b_arr;            // matrix to hold concentration of BMP
    ArrayXXd i_arr;            // matrix to hold concentration of BMPi
    ArrayXXd s_arr;            // matrix to hold concentration of pSmad
    ArrayXXd delta_b_arr;      // matrix to store temporary BMP increment
    ArrayXXd delta_i_arr;      // matrix to store temporary BMPi increment
    ArrayXXd delta_s_arr;      // matrix to store temporary pSmad increment

    std::vector<ArrayXXd> b_time;  // matrix to hold temporal data
    std::vector<ArrayXXd> i_time;  // matrix to hold temporal data
    std::vector<ArrayXXd> s_time;  // matrix to hold temporal data

    double t;   // Total time t

    //** Functions **//
    /* Constructs the object */
    NoGrowth2D();

    /* Setup circular colony in the middle of the system*/
    void create_circle_colony(); 

    /* Initial conditions */
    void create_circle_IC(); // Create a uniform circular BMP region in the system

    /* Calculate Laplacian using central finite difference with zero-flux boundaries */
    double laplacian_2d_Neumann(ArrayXXd& c, int i, int j);

    /* Perform a time-step to update the concentrations of all the species */
    void update_concs();

    /* Perform time integration of the system of PDE eqns */
    void time_integrate();

    /* Write all the conc. levels to the file */
    void write_state_to_file(const std::string& filename);

};