#ifndef STDINCLUDE
#define STDINCLUDE

#include <iostream>
#include <map>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <memory>
#include <ctype.h>
#include <random>
#include <stdio.h>
#include <cstdlib>
#include <unistd.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <sys/time.h>
#include <string.h>
#include <stdexcept>
#include <cassert>
#include <getopt.h>
#include "tqdm.hpp"

#endif