#include "sys_pde_no_growth_no_Lmx1a.hpp"

template <typename T>
std::string to_string_prec(const T a_value, const int n = 2)
{
    std::ostringstream out;
    out.precision(n);
    out << std::fixed << a_value;
    return std::move(out).str();
}

int round_double(double num) {
    num = num + 0.5 - (num<0);
    return (int) num;
}

int main(int argc, char *argv[]) {

    // Create Rxn-Diff system
    NoGrowth2D ng_sys;

    // Simulation-System Parameters
    ng_sys.dx = 1;
    ng_sys.dt = 0.05;
    ng_sys.width = 250;
    ng_sys.height = 250;
    ng_sys.radius = 100;
    ng_sys.steps = 150;
    ng_sys.tsteps = 1;

    // The defaults can be overridden from the command line
    int c;
    const char* short_opts = "a:b:c:d:e:f:g:";
    const struct option long_opts[] = {
            {"dx", required_argument, nullptr, 'a'},
            {"dt", required_argument, nullptr, 'b'},
            {"width", required_argument, nullptr, 'c'},
            {"height", required_argument, nullptr, 'd'},
            {"radius", required_argument, nullptr, 'e'},
            {"steps", required_argument, nullptr, 'f'},
            {"tsteps", required_argument, nullptr, 'g'},
            {"hille", required_argument, nullptr, 'h'},
            {"Db", required_argument, nullptr, 'i'},
            {"abs", required_argument, nullptr, 'j'},
            {"Kbs", required_argument, nullptr, 'k'},
            {"db", required_argument, nullptr, 'l'},
            {"Di", required_argument, nullptr, 'm'},
            {"ais", required_argument, nullptr, 'n'},
            {"Kis", required_argument, nullptr, 'o'},
            {"di", required_argument, nullptr, 'p'},
            {"asb", required_argument, nullptr, 'q'},
            {"Ksb", required_argument, nullptr, 'r'},
            {"Ksi", required_argument, nullptr, 's'},
            {"ds", required_argument, nullptr, 't'},
            {nullptr, required_argument, nullptr, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, short_opts, long_opts, nullptr)) != -1)
    {

        if (-1 == opt)
            break;

        switch (opt)
        {
        case 'a':
            ng_sys.dx = std::stof(optarg);
            break;
        case 'b':
            ng_sys.dt = std::stof(optarg);
            break;
        case 'c':
            ng_sys.width = std::stoi(optarg);
            break;
        case 'd':
            ng_sys.height = std::stoi(optarg);
            break;
        case 'e':
            ng_sys.radius = std::stoi(optarg);
            break;
        case 'f':
            ng_sys.steps = std::stoi(optarg);
            break;
        case 'g':
            ng_sys.tsteps = std::stoi(optarg);
            break; 
        case 'h':
            ng_sys.H = std::stoi(optarg);
            break;
        case 'i':
            ng_sys.D_b = std::stof(optarg);
            break;
        case 'j':
            ng_sys.a_b_s = std::stof(optarg);
            break;
        case 'k':
            ng_sys.K_b_s = std::stof(optarg);
            break;
        case 'l':
            ng_sys.d_b = std::stof(optarg);
            break;    
        case 'm':
            ng_sys.D_i = std::stof(optarg);
            break;
        case 'n':
            ng_sys.a_i_s = std::stof(optarg);
            break;
        case 'o':
            ng_sys.K_i_s = std::stof(optarg);
            break;
        case 'p':
            ng_sys.d_i = std::stof(optarg);
            break;
        case 'q':
            ng_sys.a_s_b = std::stof(optarg);
            break;
        case 'r':
            ng_sys.K_s_b = std::stof(optarg);
            break;
        case 's':
            ng_sys.K_s_i = std::stof(optarg);
            break;
        case 't':
            ng_sys.d_s = std::stof(optarg);
            break;    


        case '?':
            if (optopt == 'c')
                std::cerr << "Option -" << optopt << "requires an argument.\n";
            else if (isprint(optopt))
                std::cerr << "Unknown option '-" << optopt << "'.\n";
            else
                std::cerr << "Unknown option character.\n";
            return 1;
        default:
            abort();
        }
    }

    /* Re-write the parameters once the read of args is done*/
    // Re-write length and time scales interms of dx and dt
    ng_sys.width = round_double(ng_sys.width/ng_sys.dx);
    ng_sys.height = round_double(ng_sys.height/ng_sys.dx);
    ng_sys.radius = round_double(ng_sys.radius/ng_sys.dx);
    ng_sys.steps = round_double(ng_sys.steps/ng_sys.dt);
    ng_sys.tsteps = round_double(ng_sys.tsteps/ng_sys.dt);

    // Also update the Hill coefficient powers
    ng_sys.K_b_s_H = int_pow(ng_sys.K_b_s, ng_sys.H);
    ng_sys.K_i_s_H = int_pow(ng_sys.K_i_s, ng_sys.H);
    ng_sys.K_s_b_H = int_pow(ng_sys.K_s_b, ng_sys.H);
    ng_sys.K_s_i_H = int_pow(ng_sys.K_s_i, ng_sys.H);

    // Setup a circular colony
    ng_sys.create_circle_colony();

    // Set constant BMP in circular patch
    ng_sys.create_circle_IC();

    // Perform sims
    ng_sys.time_integrate();

    // Write the sim data to a file
    std::stringstream posixpath;
    posixpath << "DATA/Sim_t_" << ng_sys.steps << "_savet_" << ng_sys.tsteps << "_h_" << ng_sys.height 
              << "_w_" << ng_sys.width  << "_dt_" << ng_sys.dt << "_dx_" << ng_sys.dx << "_H_" << ng_sys.H
              << "_Db_" << ng_sys.D_b << "_abs_" << ng_sys.a_b_s << "_Kbs_" << ng_sys.K_b_s << "_db_" << ng_sys.d_b
              << "_Di_" << ng_sys.D_i << "_ais_" << ng_sys.a_i_s << "_Kis_" << ng_sys.K_i_s << "_di_" << ng_sys.d_i
              << "_asb_" << ng_sys.a_s_b << "_Ksb_" << ng_sys.K_s_b << "_Ksi_" << ng_sys.K_s_i << "_ds_" << ng_sys.d_s
              << ".nc";
    ng_sys.write_state_to_file(posixpath.str());

    // Print to test
    std::cout << ng_sys.b_time[100](150, 150) <<  std::endl;

    return 0;

}