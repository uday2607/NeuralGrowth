#include "sys_pde_no_growth.h"
#include <sstream>

template <typename T>
std::string to_string_prec(const T a_value, const int n = 2)
{
    std::ostringstream out;
    out.precision(n);
    out << std::fixed << a_value;
    return std::move(out).str();
}

int main() {

    // Simulation-System Parameters
    unsigned int width = 250;
    unsigned int height = 250;
    unsigned int radius = 100;
    double dx = 1;
    double dt = 0.05;
    unsigned int steps = 150/dt;
    unsigned int tsteps = 1/dt;

    // Create Rxn-Diff system
    NoGrowth2D ng_sys(width, height, radius, dx, dt, steps, tsteps);

    // Setup a circular colony
    ng_sys.create_circle_colony();

    // Set constant BMP in circular patch
    ng_sys.create_circle_IC();

    // Perform sims
    ng_sys.time_integrate();

    // Write the sim data to a file
    std::string file_name = "Data_L_" + to_string_prec(width) + "_R_" + to_string_prec(radius) +
                            "_dx_" + to_string_prec(dx) + "_dt_" + to_string_prec(dt) +
                            "_T_" + to_string_prec(steps) + ".dat";
    ng_sys.write_state_to_file(file_name);

    // Print to test
    std::cout << ng_sys.b_time[100](150, 150) <<  std::endl;

    return 0;

}