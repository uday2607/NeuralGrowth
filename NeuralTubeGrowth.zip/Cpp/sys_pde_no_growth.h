/**
 * Inspired from https://github.com/ifilot/turing/blob/master/src/two_dim_rd.cpp
*/
#pragma once

#include <eigen3/Eigen/Dense>
typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> MatrixXXd;
typedef Eigen::Matrix<unsigned int, Eigen::Dynamic, Eigen::Dynamic> MatrixXXu;
typedef Eigen::Matrix<int, Eigen::Dynamic, Eigen::Dynamic> MatrixXXi;

#include <iostream>
#include <map>
#include <fstream>
#include <vector>
#include "tqdm.hpp"

class NoGrowth2D {
public:

    /*
     * Setup rxn-diffusion system for diffusing species BMP (b), BMPi (i) and 
     * intrac-cellular species pSMad (s) and Lmx1a (l)
     */

    //** Parameters **//
    /* Reactions (GRN Params) */
    double D_b              = 1;      // Diffusion coefficient of BMP
    double D_i              = 1;      // Diffusion coefficient of BMPi
    double d_b              = 1/5;    // Degradation rate of BMP
    double d_i              = 1/10;   // Degradation rate of BMPi
    double d_s              = 1;      // Degradation rate of pSmad
    double d_l              = 1/8;    // Degradation rate of Lmx1a
    double a_b_s            = 1.4;    // BMP activation rate by pSmad
    double a_b_l            = 1;      // BMP activation rate by Lmx1a
    double a_l_s            = 0.08;   // Lmx1a activation rate by pSmad
    double K_i              = 0.2;    // Hill threshold inhibitor
    double K_l              = 1;      // Hill threshold Lmx1a self-activation 
    double K_s              = 0.1;    // Hill threshold pSmad self-activation switch
    double H                = 2;      // Hill coefficient
    double b0               = 0.7;    // Initial concentration of BMP

    /* System Parameters */
    unsigned int width;               // width of the system
    unsigned int height;              // height of the system
    unsigned int radius;              // radius of the cell colony
    double dx;                        // size of the space interval
    double dt;                        // size of the time interval
    unsigned int steps;               // total time, T
    unsigned int tsteps;              // number of time steps when to write a frame
    MatrixXXu in_colony;              // matrix to show if the pixel belongs to the colony

    /* Concentrations of chemical species */
    MatrixXXd b_arr;            // matrix to hold concentration of BMP
    MatrixXXd i_arr;            // matrix to hold concentration of BMPi
    MatrixXXd s_arr;            // matrix to hold concentration of pSmad
    MatrixXXd l_arr;            // matrix to hold concentration of Lmx1a
    MatrixXXd delta_b_arr;      // matrix to store temporary BMP increment
    MatrixXXd delta_i_arr;      // matrix to store temporary BMPi increment
    MatrixXXd delta_s_arr;      // matrix to store temporary pSmad increment
    MatrixXXd delta_l_arr;      // matrix to store temporary Lmx1a increment

    std::vector<MatrixXXd> b_time;  // matrix to hold temporal data
    std::vector<MatrixXXd> i_time;  // matrix to hold temporal data
    std::vector<MatrixXXd> s_time;  // matrix to hold temporal data
    std::vector<MatrixXXd> l_time;  // matrix to hold temporal data

    double t;   // Total time t

    //** Functions **//
    /* Constructs the object */
    NoGrowth2D(unsigned int _width, unsigned int _height, unsigned int _radius,
             double _dx, double _dt, unsigned int _steps, unsigned int _tsteps);

    /* Setup circular colony in the middle of the system*/
    void create_circle_colony(); 

    /* Initial conditions */
    void create_circle_IC(); // Create a uniform circular BMP region in the system

    /* Calculate Laplacian using central finite difference with zero-flux boundaries */
    void laplacian_2d_Neumann(MatrixXXd& delta_c, MatrixXXd& c);

    /* Perform a time-step to update the concentrations of all the species */
    void update_concs();

    /* Perform time integration of the system of PDE eqns */
    void time_integrate();

    /* Write all the conc. levels to the file */
    void write_state_to_file(const std::string& filename);

};