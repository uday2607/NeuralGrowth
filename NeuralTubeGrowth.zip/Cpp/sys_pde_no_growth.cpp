/**
 * Inspired from https://github.com/ifilot/turing/blob/master/src/two_dim_rd.cpp
*/
#include "sys_pde_no_growth.h"

/* Constructs the Rxn-Diff simulation object */
NoGrowth2D::NoGrowth2D(unsigned int _width, unsigned int _height, unsigned int _radius,
             double _dx, double _dt, unsigned int _steps, unsigned int _tsteps) {
        
        // Set the Sis-sys params
        width  = _width;
        height = _height;
        radius = _radius;
        dx     = _dx;
        dt     = _dt;
        steps  = _steps;
        tsteps = _tsteps;


        // Initialize the system
        this->b_arr = MatrixXXd::Zero(this->width, this->height);
        this->i_arr = MatrixXXd::Zero(this->width, this->height);
        this->s_arr = MatrixXXd::Zero(this->width, this->height);
        this->l_arr = MatrixXXd::Zero(this->width, this->height);

        this->delta_b_arr = MatrixXXd::Zero(this->width, this->height);
        this->delta_i_arr = MatrixXXd::Zero(this->width, this->height);
        this->delta_s_arr = MatrixXXd::Zero(this->width, this->height);
        this->delta_l_arr = MatrixXXd::Zero(this->width, this->height);

        // Compute the matrix to check if the pixel _i, j_ belongs to colony
        this->in_colony = MatrixXXu::Zero(this->width, this->height);

    }


/* Setup circular colony in the middle of the system*/
void NoGrowth2D::create_circle_colony() {
    
    // Colony -> circlular patch of radius _r_ centered in the system 
    for(unsigned int i = 0; i < this->height; i++) {
        for(unsigned int j = 0; j < this->width; j++) {
            double r = this->radius;
            double r2 = r*r;
            double dx = (double)(width)/2.0 - (double)j;
            double dy = (double)(height)/2.0 - (double)i;
            if( (dx*dx +dy*dy) < r2) {
                this->in_colony(i,j) = 1;
            }
        }
    }
}

/* Create a uniform circular BMP region in the system */
void NoGrowth2D::create_circle_IC() {
    for(unsigned int i = 0; i < this->height; i++) {
        for(unsigned int j = 0; j < this->width; j++) {
            // Colony -> circlular patch of radius _r_ centered in the system 
            if (this->in_colony(i,j)) {
                // Patch of BMP
                this->b_arr(i,j) = this->b0;
            }
        }
    }

    // Store the time 0 state to the
    this->b_time.push_back(this->b_arr);
    this->i_time.push_back(this->i_arr);
    this->s_time.push_back(this->s_arr);
    this->l_time.push_back(this->l_arr);
}

/* Calculate Laplacian using central finite difference with zero-flux boundaries */
void NoGrowth2D::laplacian_2d_Neumann(MatrixXXd& delta_c, MatrixXXd& c) {

    unsigned int height = this->height;
    unsigned int width = this->width;

    const double idx2 = 1.0/(this->dx*this->dx);

    for(unsigned int i = 0; i < height; i++) {
        for(unsigned int j = 0; j < width; j++) {

            double ddx = 0;
            double ddy = 0;

            // No Flux conditions
            if(i == 0) {
                ddx = c(i+1,j) - c(i, j);
            } else if(i == (height - 1)) {
                ddx = c(i-1,j) - c(i, j);
            } else {
                ddx = (-2.0 * c(i,j) + c(i-1,j) + c(i+1,j));
            }

            if(j == 0) {
                ddy = c(i,j+1) - c(i, j);
            } else if(j == (width - 1)) {
                ddy = c(i,j-1) - c(i, j);
            } else {
                ddy = (-2.0 * c(i,j) + c(i,j-1) + c(i,j+1));
            }

            // calculate laplacian
            delta_c(i,j) = (ddx + ddy) * idx2;
        }
    }
}

/* Perform a time-step to update the concentrations of all the species */
void NoGrowth2D::update_concs() {

    // Update individual concs
    // BMP is a diffusing agent => Calculate conc change due to diffusion
    laplacian_2d_Neumann(this->delta_b_arr, this->b_arr);
    this->delta_b_arr *= D_b;

    // BMPi is a diffusing agent => Calculate conc change due to diffusion
    laplacian_2d_Neumann(this->delta_i_arr, this->i_arr);
    this->delta_i_arr *= D_i;


    // Update conc using the reaction eqn
    // #pragma omp parallel for schedule(static)
    for(unsigned int i=0; i<this->height; i++) {
        for(unsigned int j=0; j<this->width; j++) {
            // Lmx1a is only present in the cell colony
            if (this->in_colony(i, j)){
                const double b_ij = this->b_arr(i,j);
                const double i_ij = this->i_arr(i,j);
                const double s_ij = this->s_arr(i,j);
                const double l_ij = this->l_arr(i,j);

                // compute PDE's LHS (Rxn kinetics)
                // BMP 
                double rb_ij = (a_b_s*s_ij + a_b_l*l_ij) - d_b*b_ij;
                // BMPi
                double ri_ij = s_ij - d_i*i_ij;
                // pSmad
                double rs_ij = pow(b_ij, H)/(pow(b_ij, H) + pow(i_ij/K_i, H)) - d_s*s_ij;
                // Lmx1a
                double rl_ij = (a_l_s*s_ij + (pow(l_ij, H)/(pow(K_l, H) + pow(b_ij, H)))*
                                (pow(s_ij, H)/(pow(K_s, H) + pow(s_ij, H)))) - d_l*l_ij;

                // Set the LHS 
                this->delta_b_arr(i,j) += rb_ij;
                this->delta_i_arr(i,j) += ri_ij;
                this->delta_l_arr(i,j) = rl_ij;
                this->delta_s_arr(i,j) = rs_ij;
            } else {
                // Set the LHS (only degradation outside the colony)
                this->delta_b_arr(i,j) -= d_b*b_arr(i,j);
                this->delta_i_arr(i,j) -= d_i*i_arr(i,j);
            }
        }
    }

    // Update the RHS of the Rxn-Diff pde
    this->b_arr += this->delta_b_arr*dt;
    this->i_arr += this->delta_i_arr*dt;
    this->s_arr += this->delta_s_arr*dt;
    this->l_arr += this->delta_l_arr*dt;

}

/* Perform time integration of the system of PDE eqns */
void NoGrowth2D::time_integrate() {
    for(int i : tq::trange(this->steps)) {
        // Save conc data every few `tSteps`
        if (i%this->tsteps == 0) {
            this->b_time.push_back(this->b_arr);
            this->i_time.push_back(this->i_arr);
            this->s_time.push_back(this->s_arr);
            this->l_time.push_back(this->l_arr);
        }

        // Integrate eqns
        this->update_concs();
    }

    // give newline after tqdm progress bar
    std::cout << std::endl;
}

/* Write all the conc. levels to the file */
void NoGrowth2D::write_state_to_file(const std::string& filename) {
    
    std::ofstream out(filename, std::ios::out | std::ios::binary | std::ios::trunc);

    typename MatrixXXd::Index rows, cols;

    // store width and height
    out.write((char*) (&this->width), sizeof(unsigned int) );
    out.write((char*) (&this->height), sizeof(unsigned int) );

    // store number of frames
    out.write((char*) (&this->tsteps), sizeof(unsigned int) );

    for(unsigned int i=0; i < b_time.size(); i++) {
        const auto& b_vals = this->b_time[i];
        const auto& s_vals = this->s_time[i];
        const auto& i_vals = this->i_time[i];
        const auto& l_vals = this->l_time[i];

        // store BMP concs.
        rows = b_vals.rows();
        cols = b_vals.cols();

        out.write((char*) b_vals.data(), rows*cols*sizeof(typename MatrixXXd::Scalar));

        // store BMPi concs.
        rows = i_vals.rows();
        cols = i_vals.cols();

        out.write((char*) i_vals.data(), rows*cols*sizeof(typename MatrixXXd::Scalar));

        // store pSmad concs.
        rows = s_vals.rows();
        cols = s_vals.cols();

        out.write((char*) s_vals.data(), rows*cols*sizeof(typename MatrixXXd::Scalar));

        // store Lmx1a concs.
        rows = i_vals.rows();
        cols = i_vals.cols();

        out.write((char*) i_vals.data(), rows*cols*sizeof(typename MatrixXXd::Scalar));
    }

    out.close();
}