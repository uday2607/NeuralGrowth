from numba import jit, float64, int8, int32, types, prange
import numpy as np

@jit(float64(float64, int32), nopython=True, nogil=True, cache=True,
     error_model="numpy", fastmath=True)
def pow(num, p):
    pow_num = num
    for i_val in range(p-1):
        pow_num *= num 

    return pow_num

@jit(float64(float64[:,:], int32, int32, float64), nopython=True, nogil=True, cache=True,
     error_model="numpy", fastmath=True)
def laplace(array_x, i, j, dx):
    
    #5 point stencil
    return (array_x[i+1, j] + array_x[i-1, j] + array_x[i, j+1] + array_x[i, j-1]
            - 4*array_x[i, j])/(dx**2)

@jit(float64[:, :](float64[:, :], int32, int32), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def impose_Neumann_boundary(array_x, Lx, Ly):

    # Update the ghost cell i -> 0 and Lx-1 and j -> 0 and Ly-1
    array_x[:, 0] = array_x[:, 2] # j-> 0 are ghost cells
    array_x[:, Ly-1] = array_x[:, Ly-3] # j-> Ly-1 are ghost cells
    array_x[0, :] = array_x[2, :] # j-> 0 are ghost cells
    array_x[Lx-1, :] = array_x[Lx-3, :] # j-> Ly-1 are ghost cells

    return array_x


@jit(float64(float64[:,:], int32, int32, float64, float64, float64[::1], float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def BMP_pde_rhs(array_b, i, j, s_val, w_val, b_params, sys_params, sol_params):

    D_b, a_b_s, K_b_s, a_b_w, K_b_w, d_b = b_params
    h = sys_params[0]
    dx = sol_params[1]

    return (D_b*laplace(array_b, i, j, dx) + 
            a_b_s*(s_val**h)/(s_val**h + K_b_s) + a_b_w*(w_val**h)/(w_val**h + K_b_w) - d_b*array_b[i, j])
    
@jit(float64(float64[:,:], int32, int32, float64, float64[::1], float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def BMP_i_pde_rhs(array_i, i, j, s_val, i_params, sys_params, sol_params):

    D_i, a_i_s, K_i_s, d_i = i_params
    h = sys_params[0]
    dx = sol_params[1]

    return (D_i*laplace(array_i, i, j, dx) + a_i_s*(s_val**h)/(s_val**h + K_i_s) - d_i*array_i[i, j])
    
@jit(float64(float64, float64, float64, float64, float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def pSmad_pde_rhs(s_val, b_val, i_val, l_val, s_params, sys_params):

    a_s_b, K_s_b, K_s_i, a_s_l, K_s_l, d_s = s_params
    h = sys_params[0]

    return (a_s_b*(b_val**h/(b_val**h + K_s_b))*(K_s_i/(K_s_i + (i_val**h))) + 
            a_s_l*(l_val**h/(l_val**h + K_s_l))
            - d_s*s_val)

@jit(float64(float64, float64, float64, float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def Lmx1a_pde_rhs(l_val, s_val, w_val, l_params, sys_params):

    a_l_s, K_l_s, a_l_w, K_l_w, d_l = l_params
    h = sys_params[0]

    return (a_l_s*(K_l_s)/(s_val**h + K_l_s) + a_l_w*(w_val**h)/(w_val**h + K_l_w) - d_l*l_val)

@jit(float64(float64[:,:], int32, int32, float64, float64, float64[::1], float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def WNT_pde_rhs(array_w, i, j, s_val, l_val, w_params, sys_params, sol_params):

    D_w, a_w_l, K_w_l, a_w_s, K_w_s, d_w = w_params
    h = sys_params[0]
    dx = sol_params[1]

    return (D_w*laplace(array_w, i, j, dx) + 
            a_w_s*(s_val**h)/(s_val**h + K_w_s) + a_w_l*(l_val**h)/(l_val**h + K_w_l) - d_w*array_w[i, j])

@jit(nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True, parallel=True)
def solve_sys_pde_lhs(array_b, array_i, array_s, array_l, array_w, b_params, i_params, s_params, 
                        l_params, w_params, sys_params, sol_params, in_circle_array):

    # Update the conccentration rates of all the chemical species acc to their PDEs
    dt, Lx, Ly = sol_params[0], np.int32(sol_params[2]), np.int32(sol_params[3])

    # make copies of old data sets
    (new_array_b, new_array_i, new_array_s, 
     new_array_l, new_array_w) = (array_b.copy(), array_i.copy(), array_s.copy(),
                                  array_l.copy(), array_w.copy())

    # Iterate through all the non-ghost mesh cell and update them
    for i in prange(1, Lx-1):
        for j in range(1, Ly-1):
            # check if the mesh cell is in the circle
            in_circle = in_circle_array[i, j]

            # Update the conc on each mesh cell
            if in_circle:

                # Update intra-cellular species too
                new_array_b[i, j] += BMP_pde_rhs(array_b, i, j, array_s[i, j], array_w[i, j], 
                                                 b_params, sys_params, sol_params)*dt
                new_array_i[i, j] += BMP_i_pde_rhs(array_i, i, j, array_s[i, j], i_params, sys_params, 
                                                   sol_params)*dt
                new_array_s[i, j] += pSmad_pde_rhs(array_s[i, j], array_b[i, j], array_i[i, j], array_l[i, j],
                                                   s_params, sys_params)*dt
                new_array_l[i, j] += Lmx1a_pde_rhs(array_l[i, j], array_s[i, j], array_w[i, j], l_params,
                                                   sys_params)*dt
                new_array_w[i, j] += WNT_pde_rhs(array_w, i, j, array_s[i, j], array_l[i, j], w_params, 
                                                 sys_params, sol_params)*dt
            else:
                # Update only the diffusing species conc
                new_array_b[i, j] += BMP_pde_rhs(array_b, i, j, 0.0, array_w[i, j], 
                                                 b_params, sys_params, sol_params)*dt
                new_array_i[i, j] += BMP_i_pde_rhs(array_i, i, j, 0.0, i_params, sys_params, 
                                                   sol_params)*dt
                new_array_w[i, j] += WNT_pde_rhs(array_w, i, j, 0.0, 0.0, w_params, 
                                                 sys_params, sol_params)*dt

    # Impose the Neumann (No flux) boundary conditions on the ghost cells
    new_array_b = impose_Neumann_boundary(new_array_b, Lx, Ly)
    new_array_i = impose_Neumann_boundary(new_array_i, Lx, Ly)
    new_array_w = impose_Neumann_boundary(new_array_w, Lx, Ly)

    return new_array_b , new_array_i, new_array_s, new_array_l, new_array_w

# Don't use Numba (don't know why but is faster)
def run_and_save_sys(array_b, array_i, array_s, array_l, array_w, b_params, i_params, s_params,
                     l_params, w_params, sys_params, sol_params):
    """Pass the initial conditions and parameters -> Returns concs at specific time points"""
    
    T, delta_t = np.int32(sol_params[5]), np.int32(sol_params[6])
    dt, Lx, Ly, R = sol_params[0], np.int32(sol_params[2]), np.int32(sol_params[3]), np.int32(sol_params[4])

    # Create arrays to save the data 
    data_b_time = np.zeros((T//delta_t, Lx, Ly))
    data_i_time = np.zeros((T//delta_t, Lx, Ly))
    data_s_time = np.zeros((T//delta_t, Lx, Ly))
    data_l_time = np.zeros((T//delta_t, Lx, Ly))
    data_w_time = np.zeros((T//delta_t, Lx, Ly))

    # NOTE: To reduce number of computations, compute the arrays before hand
    in_circle_array = np.zeros((Lx, Ly), dtype=np.int8)
    # pSmad delta function variables
    for i in range(1, Lx-1):
        for j in range(1, Ly-1):
            # check if the mesh cell is in the circle
            in_circle_array[i, j] = 1 if ((i - Lx//2)**2 + (j - Ly//2)**2) <= R**2 else 0

    save_snap_time = 0
    for t in range(T):

        # save the concs data
        if t % delta_t == 0:
            data_b_time[save_snap_time][:, :] = array_b
            data_i_time[save_snap_time][:, :] = array_i
            data_s_time[save_snap_time][:, :] = array_s
            data_l_time[save_snap_time][:, :] = array_l
            data_w_time[save_snap_time][:, :] = array_w

            save_snap_time += 1

        array_b, array_i, array_s, array_l, array_w = solve_sys_pde_lhs(array_b, array_i, array_s, array_l, 
                                                                        array_w, b_params, i_params, s_params, 
                                                                        l_params, w_params, sys_params, 
                                                                        sol_params, in_circle_array)
        
    return data_b_time, data_i_time, data_s_time, data_l_time, data_w_time

@jit(nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def create_IC_1(sys_params, sol_params):

    Lx, Ly, R = np.int32(sol_params[2]), np.int32(sol_params[3]), np.int32(sol_params[4])

    # BMP is initally only present in the circle (make it smooth for solving purposes)
    array_b = np.zeros((Lx, Ly))
    # Set the initial concentration
    for i in range(Lx):
        for j in range(Ly):
            dist = np.int32((i - Lx//2)**2 + (j - Ly//2)**2)
            if (dist <= R**2):
                array_b[i, j] = sys_params[1]
            #make it smooth
            #elif (dist <= (1.1*R)**2):
            #    array_b[i, j] = sys_params[1]*np.exp(-(dist - R**2))

    # Everyother species is set to zero 
    array_i = np.zeros((Lx, Ly))
    array_s = np.zeros((Lx, Ly))
    array_l = np.zeros((Lx, Ly))
    array_w = np.zeros((Lx, Ly))

    return array_b, array_i, array_s, array_l, array_w