from numba import jit, float64, int8, int32, types, prange
import numpy as np

@jit(float64(float64, int32), nopython=True, nogil=True, cache=True,
     error_model="numpy", fastmath=True)
def pow(num, p):
    pow_num = num
    for i_val in range(p-1):
        pow_num *= num 

    return pow_num


@jit(float64(float64, float64, float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def BMP_ode_rhs(b_val, s_val, b_params, sys_params):

    a_b_s, K_b_s, d_b = b_params
    h = sys_params[0]

    return (a_b_s*(s_val**h)/(s_val**h + K_b_s) - d_b*b_val)
    
@jit(float64(float64, float64, float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def BMP_i_ode_rhs(i_val, s_val, i_params, sys_params):

    a_i_s, K_i_s, d_i = i_params
    h = sys_params[0]

    return (a_i_s*(s_val**h)/(s_val**h + K_i_s) - d_i*i_val)
    
@jit(float64(float64, float64, float64, float64[::1], float64[::1]), 
     nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def pSmad_ode_rhs(s_val, b_val, i_val, s_params, sys_params):

    a_s_b, K_s_b, K_s_i, d_s = s_params
    h = sys_params[0]

    return (a_s_b*(b_val**h/(b_val**h + K_s_b))*(K_s_i/(K_s_i + (i_val**h))) 
            - d_s*s_val)

@jit(nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def solve_sys_ode_lhs(b_val, i_val, s_val, b_params, i_params, s_params, 
                        sys_params, sol_params):

    # Update the conccentration rates of all the chemical species acc to their PDEs
    dt = sol_params[0]

    # make copies of old data sets
    new_b, new_i, new_s = b_val, i_val, s_val

    # Update intra-cellular species too
    new_b += BMP_ode_rhs(b_val, s_val, b_params, sys_params)*dt
    new_i += BMP_i_ode_rhs(i_val, s_val, i_params, sys_params)*dt
    new_s += pSmad_ode_rhs(s_val, b_val, i_val, s_params, sys_params)*dt
 

    return new_b , new_i, new_s

# Don't use Numba (don't know why but is faster)
def run_and_save_sys(b_val, i_val, s_val, b_params, i_params, s_params,
                    sys_params, sol_params):
    """Pass the initial conditions and parameters -> Returns concs at specific time points"""
    
    T, delta_t = np.int32(sol_params[1]), np.int32(sol_params[2])

    # Create arrays to save the data 
    data_b_time = np.zeros((T//delta_t))
    data_i_time = np.zeros((T//delta_t))
    data_s_time = np.zeros((T//delta_t))

    save_snap_time = 0
    for t in range(T):

        # save the concs data
        if t % delta_t == 0:
            data_b_time[save_snap_time] = b_val
            data_i_time[save_snap_time] = i_val
            data_s_time[save_snap_time] = s_val

            save_snap_time += 1

        b_val, i_val, s_val = solve_sys_ode_lhs(b_val, i_val, s_val, b_params, i_params, s_params, 
                                    sys_params, sol_params)
        
    return data_b_time, data_i_time, data_s_time

@jit(nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def create_IC_1(sys_params):

    b_val = sys_params[1] # Over entire colony
    i_val = 0.0
    s_val = 0.0

    return b_val, i_val, s_val


