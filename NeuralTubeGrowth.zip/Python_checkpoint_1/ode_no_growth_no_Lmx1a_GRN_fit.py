import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from lmfit import minimize, Parameters, Parameter, report_fit
import numba as nb

@nb.jit(nopython=True, nogil=True, cache=True, error_model="numpy", fastmath=True)
def ode_rhs(b_val, i_val, s_val,
            h,
            a_b_s, K_b_s, d_b,
            a_i_s, K_i_s, d_i,
            a_s_b, K_s_b, K_s_i, d_s):
    
    f0 = (a_b_s*(s_val**h)/(s_val**h + K_b_s**h) - d_b*b_val)
    f1 = (a_i_s*(s_val**h)/(s_val**h + K_i_s**h) - d_i*i_val)
    f2 = (a_s_b*(b_val**h/(b_val**h + (i_val**h/K_s_i**h))) - d_s*s_val)

    return f0, f1, f2

def f(y, t, paras):
    """
    Your system of differential equations
    """

    b_val = y[0]
    i_val = y[1]
    s_val = y[2]

    h = paras["h"].value
    a_b_s, K_b_s, d_b = paras["a_b_s"].value, paras["K_b_s"].value, paras["d_b"].value
    a_i_s, K_i_s, d_i = paras["a_i_s"].value, paras["K_i_s"].value, paras["d_i"].value
    a_s_b, K_s_b, K_s_i, d_s = paras["a_s_b"].value, paras["K_s_b"].value, paras["K_s_i"].value, paras["d_s"].value
    
    # the model equations
    return ode_rhs(b_val, i_val, s_val,
            h,
            a_b_s, K_b_s, d_b,
            a_i_s, K_i_s, d_i,
            a_s_b, K_s_b, K_s_i, d_s)

def g(t, x0, paras):
    """
    Solution to the ODE x'(t) = f(t,x,k) with initial condition x(0) = x0
    """
    x = odeint(f, x0, t, args=(paras,))
    return x


def residual(paras, t, data):

    """
    compute the residual between actual data and fitted data
    """

    x0 = paras['x10'].value, paras['x20'].value, paras['x30'].value
    model = g(t, x0, paras)

    # fit only pSmad data
    x0_model = model[:, 0]/np.max(model[:, 0])
    x2_model = model[:, 2]/np.max(model[:, 2])
    res_x0 = np.zeros(len(x0_model))
    res_x0[x0_model < x0_model[0]] = 0.1

    return np.concatenate((res_x0,
                        (x2_model - data[:len(x2_model)]).ravel()))


# initial conditions
x10 = 0.7
x20 = 0.0
x30 = 0.0
y0 = [x10, x20, x30]

# measured data 56.0
t_measured = np.array([ 0,   0.5,  0.75, 1.0,   2.0,  3.0,  4.0,  5.0,  6.0,  7.,   8.0,  24.0,  48.0,  56.0,  64.0,  67.0,  70.0,  72.0,  80.0,  96.0,  110,   126,   132,   144])
x2_measured = np.array([0.0, 0.68, 0.77, 1.283, 1.12, 1.84, 1.37, 1.29, 1.80, 1.03, 0.96, 0.012, 0.00,  0.00,  0.00,  0.00,   0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00])
x2_measured /= np.max(x2_measured)
x_measured = x2_measured
print(len(x_measured))

plt.figure()
plt.scatter(t_measured, x2_measured, marker='o', color='r', label='measured data', s=75)

# set parameters including bounds; you can also fix parameters (use vary=False)
params = Parameters()
params.add('x10', value=x10, vary=False)
params.add('x20', value=x20, vary=False)
params.add('x30', value=x30, vary=False)
params.add('h', value=2, vary=False)
params.add('a_b_s', value=10, min=0.1, max=100.)
params.add('K_b_s', value=10, min=0.1, max=100.)
params.add('d_b', value=np.log(2)/8, min=np.log(2)/10, max=np.log(2)/6)
params.add('a_i_s', value=10, min=0.1, max=100.)
params.add('K_i_s', value=10, min=0.1, max=100.)
params.add('d_i', value=np.log(2)/10+0.5, min=np.log(2)/20+0.5, max=np.log(2)/5+0.5)
params.add('a_s_b', value=10, min=0.1, max=100.)
params.add('K_s_b', value=10, min=0.1, max=100.)
params.add('K_s_i', value=10, min=0.1, max=100.)
params.add('d_s', value=1/np.log(2), vary=False)

# fit model
result = minimize(residual, params, args=(t_measured, x_measured), method='leastsq')  # leastsq nelder
# check results of the fit
data_fitted = g(np.linspace(0., 144., 10000), y0, result.params)

# plot fitted data
plt.plot(np.linspace(0., 144., 10000), data_fitted[:, 2]/np.max(data_fitted[:, 2]), '-', linewidth=2, color='red', label='fitted data')
plt.plot(np.linspace(0., 144., 10000), data_fitted[:, 0]/np.max(data_fitted[:, 0]), '-', linewidth=2, color='green', label='BMP')
plt.legend()
plt.show()
# display fitted statistics
report_fit(result)

plt.show()